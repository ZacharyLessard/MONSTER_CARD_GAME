#ifndef MONSTER_H
#define MONSTER_H
#include <iostream>
#include <ostream>
#include <cstring>
using namespace std;
class card
{

protected:
	char * name;
	char * type;
	int cost;
	int ATK;
	int DEF;
	int HEAL;
	int cardNUM;
public:
	card(){
		name=new char[0];
		type=new char[0];
		cost = 0;
		ATK = 0;
		DEF = 0;
		HEAL = 0;
		cardNUM = 0;
	}
	~card(){
		delete name;
	}
	friend ostream & operator<<(ostream & out,card & Card){
		out<<Card.type<<" card"<<endl;
		out<<"Name "<<Card.name<<endl;
		out<<"ATK "<<Card.ATK<<endl;
		out<<"DEF "<<Card.DEF<<endl;
		out<<"Heal "<<Card.HEAL<<endl;
		out<<"Number "<<Card.cardNUM<<endl;
		out<<"cost " << Card.cost<<endl;
		return out;
	}
	int getAtk(card & Card)  {return Card.ATK;}
	int getDEF(card & Card)  {return Card.DEF;}
	int getHEAL(card & Card)  {return Card.HEAL;}
	int getCost(card & Card) {return Card.cost;}
	int getCard_Num(card & Card){return Card.cardNUM;}
	char * getName(card & Card) {return Card.name;}
	char * getType(card & Card) {return Card.type;}

};
//********************************************** Monster Child ************************************************

class monster : public card{
	public:
	 monster(){
	 	type = new char[8];
	 	strcpy(type, "monster");
	 }
	~monster(){
		delete type;
	}
};
class block : public card{
	public:
	block(){
		type = new char[6];
		strcpy(type, "block");
	}
	~block(){
		delete type;
	}
};
class heal : public card{
	public:
	heal(){
		type = new char[5];
		strcpy(type, "heal");
	}
	~heal(){
		delete type;
	}
};
class Slime : public monster{
	public:
		Slime(){
			delete name;
			name = new char[6];
			strcpy(name, "Slime");
	ATK = 2;
	DEF = 0;
	HEAL = 0;
	cost = 1;
	cardNUM = 1;
}
~Slime();
};
class Skeleton : public monster{
	public:
		Skeleton(){
			delete name;
			name = new char[9];
			strcpy(name, "Skeleton"); 
	ATK = 4;
	DEF = 0;
	HEAL = 0;
	cost = 2;
	cardNUM = 2;
		}
		~Skeleton();
};
class Goblin : public monster{
	public:
	Goblin(){
		delete name;
		name = new char[7];
		strcpy(name, "Goblin");
	ATK = 5;
	DEF = 0;
	HEAL = 0;
	cost = 3;
	cardNUM = 3;
	}
	~Goblin();
};
class Golem : public monster{
	public:
		Golem(){
			delete name;
			name = new char[6];
			strcpy(name, "Golem");
	ATK = 8;
	DEF = 0;
	HEAL = 0;
	cost = 4;
	cardNUM = 4;
		}
		~Golem();
};
class Dragon : public monster{
	public:
		Dragon(){
			delete name;
			name = new char[7];
			strcpy(name, "Dragon");
	ATK = 10;
	DEF = 0;
	HEAL = 0;
	cost = 5;
	cardNUM = 5;
}
~Dragon();
};
class woodenshield : public block{
	public:
		woodenshield(){
			delete name;
			name = new char[13];
			strcpy(name, "woodenshield");
	ATK = 0;
	DEF = 1;
	HEAL = 0;
	cost = 1;
	cardNUM = 6;
	}	
	~woodenshield();
};
class ironshield : public block{
	public:
		ironshield(){
			delete name;
			name = new char[11];
			strcpy(name, "ironshield");
	ATK = 0;
	DEF = 2;
	HEAL = 0;
	cost = 2;
	cardNUM = 7;
		}
	~ironshield();
};
class potion : public heal{
	public:
		potion(){
			delete name;
			name = new char[7];
			strcpy(name, "potion");
	ATK = 0;
	DEF = 0;
	HEAL = 1;
	cost = 2;
	cardNUM = 8;
		}
	~potion();
};
class elixir : public heal{
	public:
		elixir(){
			delete name;
			name = new char[7];
			strcpy(name, "elixir");
	ATK = 0;
	DEF = 0;
	HEAL = 2;
	cost = 4;
	cardNUM = 9;
		}
		~elixir();
};
template<class T>
class node{
	public:
	T * data;
	node <T> * next;
};
template<class T>
class stack{
	private:
		int size;
		node <T> * top;
	public:
	stack(){
		size = 0;
	}
	int getsize()
	{
		return size;
	}
	void push(T* d){
		node <T> * temp = new node<T>();
		temp -> data = d;
		temp -> next = top;
		top = temp;
		size++;
		}
	T* pop(){
		if(size > 0){
			T* temp = top -> data;
			node<T> * tn = top;
			top = top -> next;
			delete tn;
			size--;
			return temp;
		}
		return 0;
	}
	T * peek(){
		if(size > 0){
			return top -> data;
		}
		return 0;
}
};
template<class T>
class linkedlist{
private:
	node<T> * head;
	int size;
public:
	linkedlist()
	{
		head=0;
		size=0;
	}
	void InsertAt(int index, T* d){
		if(index == 0){
			node<T>* temp= new node<T>;
			temp -> data = d;
			temp -> next = head;
			head = temp;
			size++;
		}
		else if(index < size){
				node<T> *cursor =head;
				for(int i =0; i < index-1;i++){
					cursor = cursor -> next;
				}
			node<T>* temp = new node<T>;
			temp -> data = d;
			temp -> next = cursor -> next;
			cursor -> next = temp;
			size++;
		}
	}
	void removeAT(int index){
		if(index > size-1){
			return;
		}
		
		if(index==0){
			node<T>* temp = head;
			head = head ->next;
			delete temp;
			size--;
		}
		else{
			node<T>* cursor = head;
			for(int i=0; i<index-1;i++){
			cursor=cursor -> next;	
			}
		node<T>* temp = cursor -> next;
		cursor -> next = cursor ->next->next;
		delete temp;
		size--;
	}
	
}
	T * getDataAt (int index){
		node<T> * cursor = head;
		for(int i = 0; i<index;i++){
			cursor = cursor ->next;
		}
			return cursor -> data;
		}
	int getSize(){
		return size;
	}
	
//	T* operator[](int i){
//		return getDataAt(i);
//	}
};



#endif
