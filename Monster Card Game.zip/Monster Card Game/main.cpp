#include <iostream>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include "card.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main() {
srand(time(NULL));
linkedlist<card> playerhand;
linkedlist<card> aihand;
linkedlist<card> x;
stack<card> decks;
stack<card> aideck;
stack<card> playerdeck;
int playergold = 5;
int compgold = 5;
int playercost = 0;
int aicost = 0;
int comphp = 20;
int playerhp = 20;
	cout<<"the deck is shuffling, please wait..."<<endl;
	for(int i = 0; i <9; i++){
		card * r1 = new Slime();
		card * r2 = new Skeleton();
		card * r3 = new Goblin();
		card * r4 = new Dragon();
		card * r5 = new woodenshield();
		card * r6 = new ironshield();
     	card * r7 = new potion();
		card * r8 = new Golem();
		card * r9 = new elixir();
		
		x.InsertAt(0, r1);
		x.InsertAt(0, r2);
		x.InsertAt(0, r3);
		x.InsertAt(0, r4);
		x.InsertAt(0, r5);
		x.InsertAt(0, r6);
		x.InsertAt(0, r7);
		x.InsertAt(0, r8);
		x.InsertAt(0, r9);
}
	while (x.getSize()>0){
		int shuffle = rand() % x.getSize() + 0;
		card * y = x.getDataAt(shuffle);
		decks.push(y);
		x.removeAT(shuffle);
}
int i=0;
do{
int playercost = 0;
int aicost = 0;
	while(playerhand.getSize()<5)
	{
		playerhand.InsertAt(0, decks.peek());	
		cout << * decks.peek() << "these cards were delt to you.\n\n"<<endl;
		i++;
//		cout << "*******************************************************";
		decks.pop();
	}
	while(aihand.getSize()<5){
		aihand.InsertAt(0, decks.peek());
		cout<< * decks.peek() << "these cards delt to the computer"<< endl;
//		cout<< "***********************************************************";
		decks.pop();
	}
	aicost = 0;
	cout<< "the computer has " << compgold << " gold this turn" <<endl;
	int j = 0;
	playercost = 0;
	while(aicost<=compgold){
		card draw_cards;
		aicost = aicost + draw_cards.getCost(*aihand.getDataAt(0));
		if(aicost < compgold){	
			aideck.push(aihand.getDataAt(0));
			cout<<"the computer used:" << *aideck.peek() << endl;
			compgold = compgold - aicost;
			aihand.removeAT(0);
		}
		}
		j++;
		if(j==3){
			break;
		}
	cout<<"after that turn the computer has " << compgold << " gold: " << endl;
	cout<<"******************************************************************************" << endl;

	cout<<"\n\n\nyour hand contains: " << endl;
	for(int i = 0; i<5; i++){
		cout << i+1 << ": " << *playerhand.getDataAt(i) <<endl;
	}
	cout<< "6: " << " purchase a card" << endl;
	cout<< "********************************************************************************";
	
	cout<< "\n\n\nyou have " << playergold << " gold"<<endl;
int r = 0;
int select = 0;
int selectarray[5];
	card player_draw;
	while(select !=6 && (playergold>0))
	{
	cout<<"what would you like to do? (select 1-6): " << endl;
	cin >> select;
	if(select==6){
		break;
	}
	selectarray[r] = player_draw.getCard_Num(*playerhand.getDataAt(select-1));
	r++;
	playercost += player_draw.getCost(*playerhand.getDataAt(select-1));
	cout<< "the total cost so far is: " << playercost << endl;
	playergold -= playercost;

for(int i=0; i<r; i++)
{
	for(int j = 0; j<playerhand.getSize(); j++)
	{
		if(player_draw.getCard_Num(*playerhand.getDataAt(j))==selectarray[i])
		{
			playerdeck.push(playerhand.getDataAt(j));
			playerhand.removeAT(j);
		}
	}
}
}

	cout <<"You have " << playergold << " gold left over "<<endl;
	cout <<"The AI has " << compgold << " gold left over "<<endl;
	
		int playatk=0;
		int compatk=0;
		int playdef=0;
		int compdef=0;
		int playheal=0;
		int compheal=0;

	card aiplays;
	for(int i=0; i<aideck.getsize();i++){
		while(aideck.getsize() > 0){
			compdef = compdef + aiplays.getDEF(*playerdeck.peek());
			compatk = compatk + aiplays.getAtk(*playerdeck.peek());
			compheal = compheal + aiplays.getHEAL(*playerdeck.peek());
			aideck.pop();
		}
	}
	card players;
	for(int i=0; i<playerdeck.getsize();i++)
	{
		while(playerdeck.getsize() > 0)
		{
			playdef = playdef + players.getDEF(*playerdeck.peek());
			playatk = playatk + players.getAtk(*playerdeck.peek());
			playheal = playheal + players.getHEAL(*playerdeck.peek());
			playerdeck.pop();
		}
	}
	
	if(playatk>compatk){
		cout<<"you win!! " << endl;
		cout<<"you delt" << playatk << " damage" << endl;
		cout<<"the computer delt " << compatk << " damage" << endl;
		cout<<"you defended " << playdef << " damage" <<endl;
		cout<<"the computer defended" << compdef << " damage" << endl;
		comphp-=(playatk - compatk)-compdef;
	}
	else{
		cout<<"you lost..." <<endl;
		cout<<"you delt " << playatk << " damage " << endl;
		cout<<"the computer delt " << compatk << " damage " <<endl;
		cout<<"you defended " << playdef << " damage" << endl;
		playerhp-=(compatk-playatk)-playdef;
	}
	comphp = comphp+compheal;
	playerhp = playerhp+playheal;
	cout<<"the computers health is : " << comphp << endl;
	cout <<"Your health is : "<< playerhp << endl;
	compgold +=5;
	playergold +=5;
	
}while(playerhp>0 && comphp>0 || playergold >= 0);
if(playerhp = 0){
	cout<<"/n/nyou loose"<<endl;
}
if(comphp = 0){
	cout<<"you are victourious!!!!";
}
}






